import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

import java.awt.event.*;
import java.awt.event.KeyEvent;
import java.util.Random;



import javax.swing.*;





public class GamePanel extends JPanel implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static final int SCREEN_WIDTH = 700;
	static final int SCREEN_HEIGHT = 700;
	static final int UNIT_SIZE = 25; //size of the objects
	static final int NO_OF_UNITS = (SCREEN_WIDTH*SCREEN_HEIGHT)/UNIT_SIZE;
	static final int DELAY = 75; //higher the delay slower the game is
	final int X[] = new int[NO_OF_UNITS]; //coordinates of the snake is stored
	final int Y[] = new int[NO_OF_UNITS];
	int bodyparts = 7;
	int mangoeseaten;
	int mangoX;
	int mangoY;
	char direction = 'R';
	boolean run = false;
	Timer timer;
	Random random;
    
	

	
    GamePanel()
    {
    	random = new Random();
    	
    	this.setPreferredSize( new Dimension(SCREEN_WIDTH,SCREEN_HEIGHT));
    	this.setBackground(Color.GRAY);
    	
    	this.setFocusable(true);
    	this.addKeyListener(new MyKeyAdapter());
    	
    	
    	
    	
    	
    }
    

		

	
	
    
   
    public void StartGame(){
    	
    	
    	
    	newMango(); //to create a new mango
    
    	run = true;
    	timer = new Timer(DELAY,this); //this :is used as actionlistener interface is used
        timer.start();
        
    }
    
    

	
    
    public void paintComponent(Graphics g) {
    	super.paintComponent(g);
    	
    	draw(g);
    	
    }
   
    
    
    public void draw(Graphics g) {
    	
    	
    	if(run) {
    		
    		
    	/*
    		for(int i=0;i<SCREEN_HEIGHT/UNIT_SIZE;i++) {
    			g.drawLine(i*UNIT_SIZE,0,i*UNIT_SIZE,SCREEN_HEIGHT); //draws line in x axis
    			g.drawLine(0,i*UNIT_SIZE,SCREEN_WIDTH,i*UNIT_SIZE); //draws line in y axis
    	}
    	*/
        
    	g.setColor(Color.yellow);
    	g.fillOval(mangoX,mangoY,UNIT_SIZE,UNIT_SIZE);
    	
    	
    	
    	for(int i=0;i<bodyparts;i++) {
    		if(i==0) {
    			g.setColor(Color.RED);
    			g.fillRect(X[i],Y[i],UNIT_SIZE,UNIT_SIZE);
    			
    		}
    		else {
    			g.setColor(new Color(210,43,43));
    			g.setColor(new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255)));
    			g.fillRect(X[i],Y[i],UNIT_SIZE,UNIT_SIZE);
    			
    			
    		}
    		if(bodyparts%2==0) {
    			g.setColor(Color.RED);
    			g.fillRect(X[i],Y[i],UNIT_SIZE,UNIT_SIZE);
    		}
    	}
    	
    	g.setColor(Color.red);           //for displaying the score
    	g.setFont(new Font("Times New Roman",Font.BOLD,25));
    	FontMetrics metrics = getFontMetrics(g.getFont());
    	g.drawString("Your Score:"+mangoeseaten,(SCREEN_WIDTH - metrics.stringWidth("Your Score:"+mangoeseaten))/2,g.getFont().getSize());
    
    	g.setColor(Color.red);           //for displaying the length of the snake
    	g.setFont(new Font("Times New Roman",Font.BOLD,35));
    	
    	g.drawString("Length:"+bodyparts,480,25);
    	
    
    	
    }
    	else 
    	{
            
    		GameOver(g);
            
    	}
    }
    public void newMango() {
    	mangoX = random.nextInt((int)(SCREEN_WIDTH/UNIT_SIZE))*UNIT_SIZE; //to place the mango somewhere in the x direction
    	mangoY = random.nextInt((int)(SCREEN_WIDTH/UNIT_SIZE))*UNIT_SIZE;
    	
    }
    public void move() 
    {
    	for(int i=bodyparts;i>0;i--) //iterate through the body parts of the snake
    	{
    		X[i] = X[i - 1]; //to move one position up
    		Y[i] = Y[i - 1]; 
    	}
    	
    	switch(direction) 
    	{
    	case 'U':
    		Y[0] = Y[0] - UNIT_SIZE; //sets the head of the snake
    		break;
    	case 'D':
    		Y[0] = Y[0] + UNIT_SIZE;
    		break;
    	case 'L':
    		X[0] = X[0] - UNIT_SIZE;
    		break;
    	case 'R':
    		X[0] = X[0] + UNIT_SIZE;
    		break;
    		
    	}
    }
    public void checkMango() 
    {
    	if((X[0]==mangoX) && (Y[0]==mangoY)) {
    		bodyparts++;
    		mangoeseaten++;
    		newMango();
    	}
    }
    public void checkCollisions() 
    {
    	for(int j=bodyparts;j>0;j--)  //to check if the head collides with the bodyparts or not
    	{
    		//check if head touches body
    		if((X[0]==X[j])&& (Y[0]==Y[j])) {
    			run = false; //head is collided with the body
    		}
    		if(X[0]<0) //checking if head touches left border
    		{
    			run = false;
    		}
    		if(X[0]>SCREEN_WIDTH)  //checking if head touches right border
    		{
    			run = false;
    		}
    		if(Y[0]<0) { //if head touches top border
    			run = false;
    		}
    		if(Y[0]>SCREEN_HEIGHT) { //if head touches bottom border
    			run = false;
    		}
    		if(!run) {
    			timer.stop();
    		}
    	}
    }
    public void GameOver(Graphics g) 
    {
    	g.setColor(Color.red);           //for displaying the score
    	g.setFont(new Font("Helvetica",Font.BOLD,85));
    	FontMetrics metrics = getFontMetrics(g.getFont());
    	g.drawString("Player Score:"+mangoeseaten,(SCREEN_WIDTH - metrics.stringWidth("Your Score:"+mangoeseaten))/2,g.getFont().getSize());
    	
    	
    	g.setColor(Color.red);
    	g.setFont(new Font("Helvetica",Font.BOLD,85));
    	FontMetrics metrics1 = getFontMetrics(g.getFont());
    	g.drawString("Start Over",(SCREEN_WIDTH - metrics1.stringWidth("Start Over"))/2,SCREEN_HEIGHT/2);
    	
    	
    	
    }
    
	@Override
	public void actionPerformed(ActionEvent e) {
		if(run) 
		{
			move();
			checkMango();
			checkCollisions();
		}
		
		  repaint();

		
	}
	public class MyKeyAdapter extends KeyAdapter
	{
	   @Override
		public void keyPressed(KeyEvent e)
		{
		   switch(e.getKeyCode()) 
		   { 
		   //left arrow key && to move in the left direction
		   case KeyEvent.VK_LEFT:
			   if(direction!= 'R') 
			   {
				   direction = 'L';
			   }
			   break;
			   // right arrow key && to move in the right direction
		   case KeyEvent.VK_RIGHT:
			  if(direction!='L')
			  {
				  direction = 'R';
			  }
			  break;
			  
		   case KeyEvent.VK_UP:
			   if(direction!='D') 
			   {
				   direction = 'U';
			   }
			   break;
		   case KeyEvent.VK_DOWN:
			   if(direction!='U')
			   {
				   direction = 'D';
			   }
			   break;
		   case KeyEvent.VK_ENTER:
			   StartGame();
			   break;

		   
			   
		   
		       
			 
		   }
		   
			  
		   }
	   }
	}


