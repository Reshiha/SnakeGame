
public class SnakeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      new GameFrame();
                //an instance for that class has been created
	}

}
