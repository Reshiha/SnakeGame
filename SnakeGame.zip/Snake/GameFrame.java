import javax.swing.JFrame;

public class GameFrame extends JFrame {

	
	
	
   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

GameFrame(){
	   this.add(new GamePanel()); //creating an instance for gamepanel
	   this.setTitle("SnaKEGame");
	   this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   this.setResizable(true);
	   this.pack(); //this allows us to fit all the components that we add to the Jframe
	   this.setVisible(true);
	   this.setLocationRelativeTo(null); //to have the window in the center of the screen
	   
		
	   
	}
	   
	   
   
}

